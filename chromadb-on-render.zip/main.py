
import chromadb
from chromadb.config import Settings
from fastapi import FastAPI

app = FastAPI()

chroma_client = chromadb.Client(Settings(chroma_db_impl="duckdb+parquet", persist_directory="./data"))

@app.get("/")
def read_root():
    return {"message": "ChromaDB is running"}
